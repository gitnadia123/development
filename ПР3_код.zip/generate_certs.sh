#!/bin/bash
# Генерація PKI: Root CA, сертифікат сервера (SAN: localhost, 127.0.0.1), сертифікат клієнта (CN=dispatcher-agent-01)
set -e
mkdir -p certs && cd certs

# 1. Root CA
openssl req -x509 -newkey rsa:2048 -nodes -keyout ca.key -out ca.crt -days 365 -subj "/CN=MyRootCA"

# 2. Сертифікат сервера (із SAN localhost/127.0.0.1)
openssl req -newkey rsa:2048 -nodes -keyout server.key -out server.csr -subj "/CN=localhost"
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out server.crt -days 365 \
  -extfile <(echo "subjectAltName=DNS:localhost,IP:127.0.0.1")

# 3. Сертифікат клієнта
openssl req -newkey rsa:2048 -nodes -keyout client.key -out client.csr -subj "/CN=dispatcher-agent-01"
openssl x509 -req -in client.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out client.crt -days 365

rm -f *.csr *.srl
echo "Готово: ca.crt, server.crt, client.crt створено у certs/"
