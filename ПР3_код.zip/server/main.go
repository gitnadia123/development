package main

import (
	"bufio"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"secalert/mailer"
)

const dutyEngineer = "duty-engineer@internal.net"

func main() {
	addr := flag.String("addr", ":8443", "адреса mTLS-слухача")
	smtpAddr := flag.String("smtp", "127.0.0.1:1025", "SMTP-сервер (порожній рядок — без e-mail, рівень 1)")
	certDir := flag.String("certs", "certs", "каталог із сертифікатами")
	flag.Parse()
	log.SetFlags(0)

	cert, err := tls.LoadX509KeyPair(*certDir+"/server.crt", *certDir+"/server.key")
	if err != nil {
		log.Fatal(err)
	}
	caPEM, err := os.ReadFile(*certDir + "/ca.crt")
	if err != nil {
		log.Fatal(err)
	}
	pool := x509.NewCertPool()
	pool.AppendCertsFromPEM(caPEM)

	cfg := &tls.Config{
		Certificates: []tls.Certificate{cert},
		ClientAuth:   tls.RequireAndVerifyClientCert, // mTLS: клієнт зобов'язаний надати сертифікат
		ClientCAs:    pool,
		MinVersion:   tls.VersionTLS13,
	}

	fmt.Printf("=== Захищений шлюз критичних сповіщень (mTLS: %s, SMTP Target: %s) ===\n", *addr, *smtpAddr)
	log.Printf("[СЕРВЕР] Пул CA завантажено: ca.crt (%d сертифікат)", len(pool.Subjects()))
	l, err := tls.Listen("tcp", *addr, cfg)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("[СЕРВЕР] Слухач mTLS відкрито на порту %s", *addr)

	for {
		conn, err := l.Accept()
		if err != nil {
			log.Fatal(err)
		}
		go handle(conn.(*tls.Conn), *smtpAddr)
	}
}

func handle(conn *tls.Conn, smtpAddr string) {
	defer conn.Close()
	remote := conn.RemoteAddr().String()
	conn.SetDeadline(time.Now().Add(10 * time.Second))

	// Явне рукостискання: тут сервер перевіряє клієнтський сертифікат
	if err := conn.Handshake(); err != nil {
		log.Printf("[ВІДХИЛЕНО] З'єднання від %s відхилено на рівні TLS: %v", remote, err)
		return
	}
	log.Printf("[ПІДКЛЮЧЕННЯ] Встановлено TLS-з'єднання від %s", remote)

	// Аудит Zero Trust: ідентифікація клієнта за сертифікатом
	state := conn.ConnectionState()
	peer := state.PeerCertificates[0]
	cn := peer.Subject.CommonName
	serial := fmt.Sprintf("%X", peer.SerialNumber)
	log.Printf("[АУДИТ ZERO TRUST] Клієнт верифікований: CN=%s, Серійний номер=%s, Дійсний до=%s",
		cn, serial, peer.NotAfter.Format("2006-01-02"))

	line, err := bufio.NewReader(conn).ReadString('\n')
	if err != nil {
		log.Printf("[ПОМИЛКА] читання від %s: %v", remote, err)
		return
	}
	msg := strings.TrimSpace(line)
	log.Printf("[ПОВІДОМЛЕННЯ] Отримано інцидент: %s", msg)

	reply := "[SERVER]: ALERT RECEIVED AND VERIFIED"
	if smtpAddr != "" {
		inc := mailer.Incident{Message: msg, Time: time.Now(), Source: remote,
			ClientCN: cn, Serial: serial, NotAfter: peer.NotAfter}
		log.Printf("[SMTP] Формування MIME-повідомлення (HTML + вкладення incident_report.log)...")
		log.Printf("[SMTP] Надсилання email на %s через %s...", dutyEngineer, smtpAddr)
		if err := mailer.SendIncidentMIME(smtpAddr, dutyEngineer, inc); err != nil {
			log.Printf("[SMTP] ПОМИЛКА відправки: %v", err)
			reply = "[SERVER]: ALERT RECEIVED, EMAIL FAILED"
		} else {
			log.Printf("[SMTP] Лист про аварію успішно доставлено до поштового шлюзу!")
			reply = "[SERVER]: ALERT PROCESSED AND DISPATCHED"
		}
	}
	fmt.Fprintln(conn, reply)
	log.Printf("[ВІДПОВІДЬ] Клієнту надіслано статус: %s", reply)
}
