package main

import (
	"bufio"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"log"
	"os"
	"strings"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:8443", "адреса шлюзу")
	certDir := flag.String("certs", "certs", "каталог із сертифікатами")
	name := flag.String("cert", "client", "ім'я пари сертифікат/ключ (client)")
	msg := flag.String("msg", "CRITICAL_ERROR: Database connection timeout on node-04", "повідомлення про інцидент")
	flag.Parse()
	log.SetFlags(0)

	fmt.Println("=== Агент диспетчеризації (mTLS Client) ===")
	clientCert, err := tls.LoadX509KeyPair(*certDir+"/"+*name+".crt", *certDir+"/"+*name+".key")
	if err != nil {
		log.Fatal(err)
	}
	leaf, _ := x509.ParseCertificate(clientCert.Certificate[0])
	fmt.Printf("[КЛІЄНТ] Завантажено сертифікат клієнта: %s.crt (CN=%s)\n", *name, leaf.Subject.CommonName)

	caPEM, err := os.ReadFile(*certDir + "/ca.crt")
	if err != nil {
		log.Fatal(err)
	}
	pool := x509.NewCertPool()
	pool.AppendCertsFromPEM(caPEM)

	cfg := &tls.Config{Certificates: []tls.Certificate{clientCert}, RootCAs: pool, MinVersion: tls.VersionTLS12}
	fmt.Printf("[КЛІЄНТ] Підключення до шлюзу %s...\n", *addr)
	conn, err := tls.Dial("tcp", *addr, cfg)
	if err != nil {
		log.Fatalf("[КЛІЄНТ] Помилка підключення: %v", err)
	}
	defer conn.Close()
	fmt.Printf("[КЛІЄНТ] mTLS-рукостискання успішне. Використано протокол %s\n", tls.VersionName(conn.ConnectionState().Version))

	fmt.Printf("[КЛІЄНТ] Відправка алерту: %s\n", *msg)
	fmt.Fprintln(conn, *msg)
	reply, err := bufio.NewReader(conn).ReadString('\n')
	if err != nil {
		// у TLS 1.3 відмову в сертифікаті клієнт бачить саме під час читання
		log.Fatalf("[КЛІЄНТ] Сервер розірвав з'єднання: %v", err)
	}
	fmt.Printf("[КЛІЄНТ] Відповідь від сервера: %s\n", strings.TrimSpace(reply))
	fmt.Println("[КЛІЄНТ] Сесію успішно завершено.")
}
