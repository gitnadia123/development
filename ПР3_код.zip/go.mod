module secalert

go 1.22
