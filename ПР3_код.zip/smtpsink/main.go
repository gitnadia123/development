// Мінімальний локальний SMTP-приймач (замінник Mailpit/MailHog для тестів без Docker).
// Зберігає кожен лист у mail/NNN.eml, розбирає MIME і виводить короткий звіт.
package main

import (
	"bufio"
	"encoding/base64"
	"flag"
	"fmt"
	"io"
	"log"
	"mime"
	"mime/multipart"
	"net"
	"net/mail"
	"os"
	"path/filepath"
	"strings"
)

var counter int

func main() {
	addr := flag.String("addr", "127.0.0.1:1025", "адреса SMTP")
	dir := flag.String("dir", "mail", "каталог для листів")
	flag.Parse()
	log.SetFlags(0)
	os.MkdirAll(*dir, 0o755)
	l, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("[SMTP-SINK] Слухаю %s (SMTP-емулятор, аналог Mailpit)", *addr)
	for {
		c, err := l.Accept()
		if err != nil {
			return
		}
		go session(c, *dir)
	}
}

func session(c net.Conn, dir string) {
	defer c.Close()
	r := bufio.NewReader(c)
	w := func(s string) { fmt.Fprintf(c, "%s\r\n", s) }
	w("220 smtp-sink ESMTP ready")
	var from string
	var rcpt []string
	for {
		line, err := r.ReadString('\n')
		if err != nil {
			return
		}
		cmd := strings.ToUpper(strings.TrimSpace(line))
		switch {
		case strings.HasPrefix(cmd, "EHLO"), strings.HasPrefix(cmd, "HELO"):
			w("250-smtp-sink")
			w("250 8BITMIME")
		case strings.HasPrefix(cmd, "MAIL FROM"):
			from = strings.TrimSpace(line[10:])
			w("250 OK")
		case strings.HasPrefix(cmd, "RCPT TO"):
			rcpt = append(rcpt, strings.TrimSpace(line[8:]))
			w("250 OK")
		case cmd == "DATA":
			w("354 End data with <CR><LF>.<CR><LF>")
			var sb strings.Builder
			for {
				l, err := r.ReadString('\n')
				if err != nil {
					return
				}
				if strings.TrimRight(l, "\r\n") == "." {
					break
				}
				if strings.HasPrefix(l, "..") {
					l = l[1:]
				}
				sb.WriteString(l)
			}
			counter++
			path := filepath.Join(dir, fmt.Sprintf("%03d.eml", counter))
			os.WriteFile(path, []byte(sb.String()), 0o644)
			report(path, sb.String(), from, rcpt, dir)
			w("250 OK queued")
		case cmd == "QUIT":
			w("221 Bye")
			return
		case cmd == "RSET":
			w("250 OK")
		default:
			w("250 OK")
		}
	}
}

func report(path, raw, from string, rcpt []string, dir string) {
	log.Printf("[SMTP-SINK] Новий лист → %s (MAIL FROM %s, RCPT TO %v)", path, from, rcpt)
	m, err := mail.ReadMessage(strings.NewReader(raw))
	if err != nil {
		log.Printf("[SMTP-SINK] помилка розбору: %v", err)
		return
	}
	dec := new(mime.WordDecoder)
	subj, _ := dec.DecodeHeader(m.Header.Get("Subject"))
	log.Printf("[SMTP-SINK]   From: %s | To: %s", m.Header.Get("From"), m.Header.Get("To"))
	log.Printf("[SMTP-SINK]   Subject: %s", subj)
	mt, params, _ := mime.ParseMediaType(m.Header.Get("Content-Type"))
	log.Printf("[SMTP-SINK]   Content-Type: %s", mt)
	if !strings.HasPrefix(mt, "multipart/") {
		return
	}
	mr := multipart.NewReader(m.Body, params["boundary"])
	for {
		p, err := mr.NextPart()
		if err == io.EOF {
			break
		}
		if err != nil {
			return
		}
		body, _ := io.ReadAll(p)
		data := body
		if p.Header.Get("Content-Transfer-Encoding") == "base64" {
			data, _ = base64.StdEncoding.DecodeString(strings.ReplaceAll(strings.ReplaceAll(string(body), "\r", ""), "\n", ""))
		}
		pm, _, _ := mime.ParseMediaType(p.Header.Get("Content-Type"))
		if fn := p.FileName(); fn != "" {
			os.WriteFile(filepath.Join(dir, fn), data, 0o644)
			log.Printf("[SMTP-SINK]   Вкладення: %s (%s, %d байт) — збережено", fn, pm, len(data))
		} else {
			os.WriteFile(filepath.Join(dir, "body.html"), data, 0o644)
			log.Printf("[SMTP-SINK]   Секція: %s (%d байт) — збережено як body.html", pm, len(data))
		}
	}
}
