// Пакет mailer — відправка листів через net/smtp (простий текст та MIME multipart).
package mailer

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"mime"
	"net/smtp"
	"strings"
	"time"
)

const (
	From = "alert-gateway@internal.net"
)

// encodeSubject кодує тему з не-ASCII символами за RFC 2047.
func encodeSubject(s string) string { return mime.QEncoding.Encode("UTF-8", s) }

// SendText — параметризована відправка простого листа (рівень 2):
// приймає адресу SMTP-сервера, отримувача, тему та текст.
func SendText(smtpAddr, to, subject, body string) error {
	var b bytes.Buffer
	fmt.Fprintf(&b, "From: %s\r\n", From)
	fmt.Fprintf(&b, "To: %s\r\n", to)
	fmt.Fprintf(&b, "Subject: %s\r\n", encodeSubject(subject))
	fmt.Fprintf(&b, "Date: %s\r\n", time.Now().Format(time.RFC1123Z))
	b.WriteString("MIME-Version: 1.0\r\n")
	b.WriteString("Content-Type: text/plain; charset=UTF-8\r\n\r\n")
	b.WriteString(body)
	return smtp.SendMail(smtpAddr, nil, From, []string{to}, b.Bytes())
}

// Incident — дані для багатокомпонентного листа.
type Incident struct {
	Message  string
	Time     time.Time
	Source   string // адреса джерела
	ClientCN string // CN із сертифіката
	Serial   string
	NotAfter time.Time
}

func (i Incident) report() string {
	return fmt.Sprintf(`=== INCIDENT REPORT ===
Час реєстрації : %s
Джерело (IP)   : %s
Клієнт (CN)    : %s
Серійний номер : %s
Сертифікат до  : %s
Повідомлення   : %s
Транспорт      : mTLS (TLS 1.3), клієнт верифікований Root CA
`, i.Time.Format(time.RFC3339), i.Source, i.ClientCN, i.Serial, i.NotAfter.Format(time.RFC3339), i.Message)
}

func (i Incident) html() string {
	return fmt.Sprintf(`<html><body style="font-family:Arial,sans-serif">
<div style="border-left:8px solid #d32f2f;padding:10px 16px;background:#fdecea">
 <h2 style="margin:0;color:#d32f2f">&#9679; КРИТИЧНА ТРИВОГА</h2>
</div>
<table style="border-collapse:collapse;margin-top:14px" cellpadding="8">
 <tr><td style="border:1px solid #ccc"><b>Подія</b></td><td style="border:1px solid #ccc">%s</td></tr>
 <tr><td style="border:1px solid #ccc"><b>Час</b></td><td style="border:1px solid #ccc">%s</td></tr>
 <tr><td style="border:1px solid #ccc"><b>Джерело</b></td><td style="border:1px solid #ccc">%s</td></tr>
 <tr><td style="border:1px solid #ccc"><b>Ідентифікатор із сертифіката</b></td><td style="border:1px solid #ccc">CN=%s</td></tr>
 <tr><td style="border:1px solid #ccc"><b>Серійний номер</b></td><td style="border:1px solid #ccc">%s</td></tr>
</table>
<p style="color:#555">Запит надійшов від верифікованого пристрою [CN=%s]. Технічний звіт — у вкладенні incident_report.log.</p>
</body></html>`, i.Message, i.Time.Format("2006-01-02 15:04:05 MST"), i.Source, i.ClientCN, i.Serial, i.ClientCN)
}

// base64Wrapped кодує дані та розбиває на рядки по 76 символів (RFC 2045).
func base64Wrapped(data []byte) string {
	enc := base64.StdEncoding.EncodeToString(data)
	var sb strings.Builder
	for len(enc) > 76 {
		sb.WriteString(enc[:76] + "\r\n")
		enc = enc[76:]
	}
	sb.WriteString(enc + "\r\n")
	return sb.String()
}

// SendIncidentMIME формує multipart/mixed лист: HTML-секція + вкладення incident_report.log (Base64).
func SendIncidentMIME(smtpAddr, to string, inc Incident) error {
	boundary := fmt.Sprintf("==ALERT_BOUNDARY_%d==", time.Now().UnixNano())
	var b bytes.Buffer
	fmt.Fprintf(&b, "From: %s\r\n", From)
	fmt.Fprintf(&b, "To: %s\r\n", to)
	fmt.Fprintf(&b, "Subject: %s\r\n", encodeSubject("[КРИТИЧНО] Аварійне сповіщення: "+inc.Message))
	fmt.Fprintf(&b, "Date: %s\r\n", time.Now().Format(time.RFC1123Z))
	b.WriteString("MIME-Version: 1.0\r\n")
	fmt.Fprintf(&b, "Content-Type: multipart/mixed; boundary=\"%s\"\r\n\r\n", boundary)

	// Секція 1: HTML
	fmt.Fprintf(&b, "--%s\r\n", boundary)
	b.WriteString("Content-Type: text/html; charset=UTF-8\r\n")
	b.WriteString("Content-Transfer-Encoding: base64\r\n\r\n")
	b.WriteString(base64Wrapped([]byte(inc.html())))

	// Секція 2: вкладення
	fmt.Fprintf(&b, "--%s\r\n", boundary)
	b.WriteString("Content-Type: text/plain; name=\"incident_report.log\"\r\n")
	b.WriteString("Content-Disposition: attachment; filename=\"incident_report.log\"\r\n")
	b.WriteString("Content-Transfer-Encoding: base64\r\n\r\n")
	b.WriteString(base64Wrapped([]byte(inc.report())))

	fmt.Fprintf(&b, "--%s--\r\n", boundary)
	return smtp.SendMail(smtpAddr, nil, From, []string{to}, b.Bytes())
}
