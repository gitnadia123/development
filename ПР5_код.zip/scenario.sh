#!/usr/bin/env bash
# Повний сценарій перевірки (сервер має працювати на :8080)
B=http://localhost:8080/api/v1
echo "== 1. Реєстрація";                 curl -s -i -X POST $B/auth/register -H 'Content-Type: application/json' -d '{"email":"engineer@company.internal","password":"SuperSecretPassword123"}'
echo; echo "== 2. Логін";                TOKEN=$(curl -s -X POST $B/auth/login -H 'Content-Type: application/json' -d '{"email":"engineer@company.internal","password":"SuperSecretPassword123"}' | sed -E 's/.*"token":"([^"]+)".*/\1/'); echo "$TOKEN"
echo "== 3. Невірний пароль (401)";      curl -s -i -X POST $B/auth/login -H 'Content-Type: application/json' -d '{"email":"engineer@company.internal","password":"wrong"}'
echo; echo "== 4. Створення без токена (401)"; curl -s -i -X POST $B/incidents -H 'Content-Type: application/json' -d '{"title":"abc","description":"x","priority":"low"}'
echo; echo "== 5. Невалідний пріоритет (400)"; curl -s -i -X POST $B/incidents -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"title":"Overheating","description":"x","priority":"urgent"}'
echo; echo "== 6. Створення (201)";        curl -s -i -X POST $B/incidents -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"title":"Overheating on Gateway-01","description":"Core temperature reached 85C","priority":"critical"}'
echo; echo "== 7. Список";                curl -s -i $B/incidents
echo; echo "== 8. Один запис";             curl -s -i $B/incidents/1
echo; echo "== 9. Зміна статусу";          curl -s -i -X PATCH $B/incidents/1/status -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"status":"in_progress"}'
echo; echo "== 10. Неіснуючий (404)";      curl -s -i $B/incidents/999
echo; echo "== 11. DELETE без токена (401)"; curl -s -i -X DELETE $B/incidents/1
echo; echo "== 12. DELETE з токеном (204)";  curl -s -i -X DELETE $B/incidents/1 -H "Authorization: Bearer $TOKEN"
