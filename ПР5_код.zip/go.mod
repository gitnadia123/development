module incident-tracker

go 1.22
