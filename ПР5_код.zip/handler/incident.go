package handler

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"

	"incident-tracker/dto"
	"incident-tracker/models"
)

// parseID зчитує :id зі шляху.
func parseID(c *gin.Context) (uint, bool) {
	id, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, dto.ErrorResponse{Error: "invalid id"})
		return 0, false
	}
	return uint(id), true
}

// findIncident шукає запис; при помилці сам відправляє відповідь.
func (h *Handler) findIncident(c *gin.Context, id uint) (*models.Incident, bool) {
	var inc models.Incident
	if err := h.DB.First(&inc, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(http.StatusNotFound, dto.ErrorResponse{Error: "incident not found"})
		} else {
			c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "database error"})
		}
		return nil, false
	}
	return &inc, true
}

// ListIncidentsHandler godoc
// @Summary  Список інцидентів (публічний)
// @Tags     incidents
// @Produce  json
// @Success  200  {array}  models.Incident
// @Router   /incidents [get]
func (h *Handler) ListIncidentsHandler(c *gin.Context) {
	var incidents []models.Incident
	if err := h.DB.Order("id").Find(&incidents).Error; err != nil {
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "database error"})
		return
	}
	c.JSON(http.StatusOK, incidents)
}

// GetIncidentHandler godoc
// @Summary  Один інцидент (публічний)
// @Tags     incidents
// @Produce  json
// @Param    id   path      int  true  "ID інциденту"
// @Success  200  {object}  models.Incident
// @Failure  404  {object}  dto.ErrorResponse
// @Router   /incidents/{id} [get]
func (h *Handler) GetIncidentHandler(c *gin.Context) {
	id, ok := parseID(c)
	if !ok {
		return
	}
	if inc, ok := h.findIncident(c, id); ok {
		c.JSON(http.StatusOK, inc)
	}
}

// CreateIncidentHandler godoc
// @Summary   Створити інцидент
// @Tags      incidents
// @Accept    json
// @Produce   json
// @Security  BearerAuth
// @Param     input  body      dto.CreateIncidentDTO  true  "Дані інциденту"
// @Success   201    {object}  models.Incident
// @Failure   400    {object}  dto.ValidationErrorResponse
// @Failure   401    {object}  dto.ErrorResponse
// @Router    /incidents [post]
func (h *Handler) CreateIncidentHandler(c *gin.Context) {
	var in dto.CreateIncidentDTO
	if err := c.ShouldBindJSON(&in); err != nil {
		bindError(c, err)
		return
	}
	userID, _ := c.Get("userID")
	uid, _ := userID.(uint)
	inc := models.Incident{
		Title: in.Title, Description: in.Description, Priority: in.Priority,
		Status: "open", UserID: uid,
	}
	if err := h.DB.Create(&inc).Error; err != nil {
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "database error"})
		return
	}
	c.JSON(http.StatusCreated, inc)
}

// UpdateStatusHandler godoc
// @Summary   Змінити статус інциденту
// @Tags      incidents
// @Accept    json
// @Produce   json
// @Security  BearerAuth
// @Param     id     path      int                 true  "ID інциденту"
// @Param     input  body      dto.UpdateStatusDTO  true  "Новий статус"
// @Success   200    {object}  models.Incident
// @Failure   400    {object}  dto.ValidationErrorResponse
// @Failure   401    {object}  dto.ErrorResponse
// @Failure   404    {object}  dto.ErrorResponse
// @Router    /incidents/{id}/status [patch]
func (h *Handler) UpdateStatusHandler(c *gin.Context) {
	id, ok := parseID(c)
	if !ok {
		return
	}
	var in dto.UpdateStatusDTO
	if err := c.ShouldBindJSON(&in); err != nil {
		bindError(c, err)
		return
	}
	inc, ok := h.findIncident(c, id)
	if !ok {
		return
	}
	if err := h.DB.Model(inc).Update("status", in.Status).Error; err != nil {
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "database error"})
		return
	}
	c.JSON(http.StatusOK, inc)
}

// DeleteIncidentHandler godoc
// @Summary   Видалити інцидент
// @Tags      incidents
// @Security  BearerAuth
// @Param     id   path  int  true  "ID інциденту"
// @Success   204  "No Content"
// @Failure   401  {object}  dto.ErrorResponse
// @Failure   404  {object}  dto.ErrorResponse
// @Router    /incidents/{id} [delete]
func (h *Handler) DeleteIncidentHandler(c *gin.Context) {
	id, ok := parseID(c)
	if !ok {
		return
	}
	inc, ok := h.findIncident(c, id)
	if !ok {
		return
	}
	if err := h.DB.Delete(inc).Error; err != nil {
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "database error"})
		return
	}
	c.Status(http.StatusNoContent)
}
