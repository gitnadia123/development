package handler

import (
	"errors"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"

	"incident-tracker/auth"
	"incident-tracker/dto"
	"incident-tracker/models"
)

// RegisterHandler godoc
// @Summary      Реєстрація інженера
// @Tags         auth
// @Accept       json
// @Produce      json
// @Param        input  body      dto.RegisterDTO  true  "Облікові дані"
// @Success      201    {object}  models.User
// @Failure      400    {object}  dto.ValidationErrorResponse
// @Failure      409    {object}  dto.ErrorResponse
// @Router       /auth/register [post]
func (h *Handler) RegisterHandler(c *gin.Context) {
	var in dto.RegisterDTO
	if err := c.ShouldBindJSON(&in); err != nil {
		bindError(c, err)
		return
	}
	var count int64
	h.DB.Model(&models.User{}).Where("email = ?", in.Email).Count(&count)
	if count > 0 {
		c.JSON(http.StatusConflict, dto.ErrorResponse{Error: "user with this email already exists"})
		return
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(in.Password), bcrypt.DefaultCost)
	if err != nil {
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "cannot hash password"})
		return
	}
	user := models.User{Email: in.Email, PasswordHash: string(hash)}
	if err := h.DB.Create(&user).Error; err != nil {
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "cannot create user"})
		return
	}
	c.JSON(http.StatusCreated, user) // PasswordHash приховано тегом json:"-"
}

// LoginHandler godoc
// @Summary      Вхід та отримання JWT
// @Tags         auth
// @Accept       json
// @Produce      json
// @Param        input  body      dto.LoginDTO  true  "Облікові дані"
// @Success      200    {object}  dto.TokenResponse
// @Failure      400    {object}  dto.ValidationErrorResponse
// @Failure      401    {object}  dto.ErrorResponse
// @Router       /auth/login [post]
func (h *Handler) LoginHandler(c *gin.Context) {
	var in dto.LoginDTO
	if err := c.ShouldBindJSON(&in); err != nil {
		bindError(c, err)
		return
	}
	var user models.User
	err := h.DB.Where("email = ?", in.Email).First(&user).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(http.StatusUnauthorized, dto.ErrorResponse{Error: "invalid credentials"})
			return
		}
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "database error"})
		return
	}
	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(in.Password)); err != nil {
		c.JSON(http.StatusUnauthorized, dto.ErrorResponse{Error: "invalid credentials"})
		return
	}
	token, err := auth.GenerateToken(user.ID, h.JWTSecret, 24*time.Hour)
	if err != nil {
		c.JSON(http.StatusInternalServerError, dto.ErrorResponse{Error: "cannot sign token"})
		return
	}
	c.JSON(http.StatusOK, dto.TokenResponse{Token: token})
}
