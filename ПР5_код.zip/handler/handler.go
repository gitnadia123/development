package handler

import (
	"errors"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	"gorm.io/gorm"

	"incident-tracker/dto"
)

// Handler зберігає залежності обробників.
type Handler struct {
	DB        *gorm.DB
	JWTSecret string
}

func fieldMessage(fe validator.FieldError) string {
	switch fe.Tag() {
	case "required":
		return "поле обов'язкове"
	case "min":
		return fmt.Sprintf("мінімальна довжина/значення: %s", fe.Param())
	case "max":
		return fmt.Sprintf("максимальна довжина/значення: %s", fe.Param())
	case "oneof":
		return fmt.Sprintf("допустимі значення: %s", fe.Param())
	case "email":
		return "некоректний формат email"
	}
	return "некоректне значення (" + fe.Tag() + ")"
}

// bindError повертає 400 з детальним переліком некоректних полів.
func bindError(c *gin.Context, err error) {
	var ve validator.ValidationErrors
	if errors.As(err, &ve) {
		fields := make([]dto.FieldError, 0, len(ve))
		for _, fe := range ve {
			fields = append(fields, dto.FieldError{Field: fe.Field(), Message: fieldMessage(fe)})
		}
		c.JSON(http.StatusBadRequest, dto.ValidationErrorResponse{Error: "validation failed", Fields: fields})
		return
	}
	c.JSON(http.StatusBadRequest, dto.ErrorResponse{Error: "invalid request body: " + err.Error()})
}
