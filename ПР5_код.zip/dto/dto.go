package dto

// CreateIncidentDTO — тіло запиту на створення інциденту.
type CreateIncidentDTO struct {
	Title       string `json:"title" binding:"required,min=3,max=100" example:"Overheating on Gateway-01"`
	Description string `json:"description" binding:"required" example:"Core temperature reached 85C"`
	Priority    string `json:"priority" binding:"required,oneof=low medium high critical" example:"critical"`
}

// UpdateStatusDTO — зміна статусу інциденту.
type UpdateStatusDTO struct {
	Status string `json:"status" binding:"required,oneof=open in_progress resolved closed" example:"in_progress"`
}

// RegisterDTO — реєстрація користувача.
type RegisterDTO struct {
	Email    string `json:"email" binding:"required,email" example:"engineer@company.internal"`
	Password string `json:"password" binding:"required,min=6" example:"SuperSecretPassword123"`
}

// LoginDTO — автентифікація користувача.
type LoginDTO struct {
	Email    string `json:"email" binding:"required,email" example:"engineer@company.internal"`
	Password string `json:"password" binding:"required" example:"SuperSecretPassword123"`
}

// TokenResponse — відповідь з JWT.
type TokenResponse struct {
	Token string `json:"token"`
}

// ErrorResponse — стандартна помилка.
type ErrorResponse struct {
	Error string `json:"error"`
}

// FieldError — опис некоректного поля при помилці валідації.
type FieldError struct {
	Field   string `json:"field"`
	Message string `json:"message"`
}

// ValidationErrorResponse — перелік некоректних полів.
type ValidationErrorResponse struct {
	Error  string       `json:"error"`
	Fields []FieldError `json:"fields"`
}
