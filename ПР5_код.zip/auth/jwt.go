package auth

import (
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// Claims — корисне навантаження токена.
type Claims struct {
	UserID uint `json:"userID"`
	jwt.RegisteredClaims
}

// GenerateToken створює підписаний (HS256) JWT зі строком дії ttl.
func GenerateToken(userID uint, secret string, ttl time.Duration) (string, error) {
	claims := Claims{
		UserID: userID,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(ttl)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString([]byte(secret))
}
