package main

import (
	"log"

	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"

	"incident-tracker/config"
	_ "incident-tracker/docs" // згенерується командою `swag init`
	"incident-tracker/handler"
	"incident-tracker/middleware"
	"incident-tracker/models"
)

// @title           Incident Tracker API
// @version         1.0
// @description     Облік технічних інцидентів: Gin + PostgreSQL (GORM) + JWT.
// @host            localhost:8080
// @BasePath        /api/v1
// @securityDefinitions.apikey  BearerAuth
// @in                          header
// @name                        Authorization
// @description                 Введіть: Bearer <jwt-токен>
func main() {
	db, err := config.ConnectDB()
	if err != nil {
		log.Fatal(err)
	}
	if err := db.AutoMigrate(&models.User{}, &models.Incident{}); err != nil {
		log.Fatal(err)
	}
	log.Println("[GORM] Auto-migration completed: 'users', 'incidents' tables are up to date.")

	secret := config.Getenv("JWT_SECRET", "dev-secret-change-me")
	h := &handler.Handler{DB: db, JWTSecret: secret}

	r := gin.Default()
	v1 := r.Group("/api/v1")
	{
		v1.POST("/auth/register", h.RegisterHandler)
		v1.POST("/auth/login", h.LoginHandler)
		v1.GET("/incidents", h.ListIncidentsHandler)
		v1.GET("/incidents/:id", h.GetIncidentHandler)

		protected := v1.Group("")
		protected.Use(middleware.AuthMiddleware(secret))
		{
			protected.POST("/incidents", h.CreateIncidentHandler)
			protected.PATCH("/incidents/:id/status", h.UpdateStatusHandler)
			protected.DELETE("/incidents/:id", h.DeleteIncidentHandler)
		}
	}
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	addr := config.Getenv("ADDR", ":8080")
	log.Printf("[СЕРВЕР] Сервіс запущено на http://localhost%s", addr)
	log.Printf("[СЕРВЕР] Swagger UI: http://localhost%s/swagger/index.html", addr)
	if err := r.Run(addr); err != nil {
		log.Fatal(err)
	}
}
