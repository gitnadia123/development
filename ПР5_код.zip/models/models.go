package models

import "time"

// Incident — технічний інцидент/аварія.
type Incident struct {
	ID          uint      `gorm:"primaryKey" json:"id"`
	Title       string    `gorm:"size:100;not null" json:"title"`
	Description string    `gorm:"type:text;not null" json:"description"`
	Priority    string    `gorm:"size:20;not null" json:"priority"`
	Status      string    `gorm:"size:20;not null;default:open" json:"status"`
	UserID      uint      `gorm:"index" json:"user_id"`
	CreatedAt   time.Time `json:"created_at"`
}

// User — обліковий запис інженера.
type User struct {
	ID           uint      `gorm:"primaryKey" json:"id"`
	Email        string    `gorm:"uniqueIndex;not null" json:"email"`
	PasswordHash string    `gorm:"not null" json:"-"` // ніколи не серіалізується
	CreatedAt    time.Time `json:"created_at"`
}
