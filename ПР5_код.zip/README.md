# Incident Tracker API (Практична робота №5, Go + Gin + PostgreSQL + JWT + Swagger)

## Запуск
```bash
docker run -d --name postgres-dev -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres:alpine
go mod tidy                                   # завантажить gin, gorm, pgx-драйвер, bcrypt, jwt, swag
go install github.com/swaggo/swag/cmd/swag@latest
swag init                                     # створить ./docs (потрібен для імпорту в main.go)
go run .                                      # JWT_SECRET, DB_DSN, ADDR — змінні середовища
```
Swagger UI: http://localhost:8080/swagger/index.html. Сценарій перевірки: `bash scenario.sh`.
