package config

import (
	"fmt"
	"log"
	"os"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// Getenv повертає змінну середовища або значення за замовчуванням.
func Getenv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

// ConnectDB відкриває пул з'єднань з PostgreSQL та перевіряє зв'язок.
func ConnectDB() (*gorm.DB, error) {
	dsn := Getenv("DB_DSN", "host=localhost user=postgres password=postgres dbname=postgres port=5432 sslmode=disable")
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		return nil, fmt.Errorf("підключення до PostgreSQL: %w", err)
	}
	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}
	if err := sqlDB.Ping(); err != nil {
		return nil, fmt.Errorf("ping PostgreSQL: %w", err)
	}
	log.Println("[GORM] Connected to PostgreSQL successfully")
	return db, nil
}
