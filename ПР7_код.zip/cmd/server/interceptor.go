package main

import (
	"context"
	"log"
	"os"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/peer"
	"google.golang.org/grpc/status"
)

// apiKey — сервісний ключ (можна перевизначити змінною MEDIA_API_KEY).
var apiKey = func() string {
	if v := os.Getenv("MEDIA_API_KEY"); v != "" {
		return v
	}
	return "secret-media-token"
}()

func clientAddr(ctx context.Context) string {
	if p, ok := peer.FromContext(ctx); ok {
		return p.Addr.String()
	}
	return "unknown"
}

// checkAuth перевіряє заголовок x-api-key у метаданих вхідного запиту.
func checkAuth(ctx context.Context) error {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return status.Error(codes.Unauthenticated, "Invalid or missing API key")
	}
	keys := md.Get("x-api-key")
	if len(keys) == 0 || keys[0] != apiKey {
		return status.Error(codes.Unauthenticated, "Invalid or missing API key")
	}
	return nil
}

// serverInterceptor — Unary Interceptor: автентифікація + логування + хронометраж.
func serverInterceptor(ctx context.Context, req any, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (any, error) {
	start := time.Now()
	auth := "SUCCESS"
	var resp any
	err := checkAuth(ctx)
	if err != nil {
		auth = "REJECTED"
	} else {
		resp, err = handler(ctx, req)
	}
	log.Printf("[INTERCEPTOR] Unary call Method=%s Client=%s Auth=%s Status=%s Duration=%s",
		info.FullMethod, clientAddr(ctx), auth, status.Code(err), time.Since(start))
	return resp, err
}

// streamInterceptor — аналогічний захист для потокових методів (TrackProgress).
func streamInterceptor(srv any, ss grpc.ServerStream, info *grpc.StreamServerInfo, handler grpc.StreamHandler) error {
	start := time.Now()
	auth := "SUCCESS"
	err := checkAuth(ss.Context())
	if err != nil {
		auth = "REJECTED"
	} else {
		err = handler(srv, ss)
	}
	log.Printf("[INTERCEPTOR] Stream call Method=%s Client=%s Auth=%s Status=%s Duration=%s",
		info.FullMethod, clientAddr(ss.Context()), auth, status.Code(err), time.Since(start))
	return err
}
