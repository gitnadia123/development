package main

import (
	"context"
	"crypto/rand"
	"fmt"
	"log"
	"net"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	mediapb "media-service/proto"
)

const (
	statusQueued     = "QUEUED"
	statusProcessing = "PROCESSING"
	statusCompleted  = "COMPLETED"
)

type job struct {
	ID          string
	Filename    string
	Format      mediapb.MediaFormat
	Status      string
	Progress    int32
	CreatedAt   int64
	CompletedAt int64
}

type server struct {
	mediapb.UnimplementedMediaServiceServer
	mu   sync.RWMutex
	jobs map[string]*job
}

func newServer() *server { return &server{jobs: make(map[string]*job)} }

// newUUID формує UUID v4 без зовнішніх залежностей.
func newUUID() string {
	var b [16]byte
	_, _ = rand.Read(b[:])
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}

func (s *server) SubmitJob(ctx context.Context, req *mediapb.ProcessMediaRequest) (*mediapb.JobResponse, error) {
	if req.GetClientId() == "" || req.GetFilename() == "" {
		return nil, status.Error(codes.InvalidArgument, "client_id and filename are required")
	}
	if q := req.GetQualityLevel(); q < 1 || q > 100 {
		return nil, status.Error(codes.InvalidArgument, "quality_level must be in range 1..100")
	}
	if req.GetTargetFormat() == mediapb.MediaFormat_MEDIA_FORMAT_UNSPECIFIED {
		return nil, status.Error(codes.InvalidArgument, "target_format must be specified")
	}
	j := &job{
		ID: newUUID(), Filename: req.GetFilename(), Format: req.GetTargetFormat(),
		Status: statusQueued, CreatedAt: time.Now().Unix(),
	}
	s.mu.Lock()
	s.jobs[j.ID] = j
	s.mu.Unlock()
	log.Printf("[STORAGE] Job registered: ID=%s Filename=%s TargetFormat=%s Status=%s", j.ID, j.Filename, j.Format, j.Status)
	return &mediapb.JobResponse{JobId: j.ID, Status: j.Status, CreatedAt: j.CreatedAt}, nil
}

func (s *server) GetJobStatus(ctx context.Context, req *mediapb.GetJobStatusRequest) (*mediapb.JobStatusResponse, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	j, ok := s.jobs[req.GetJobId()]
	if !ok {
		return nil, status.Errorf(codes.NotFound, "job %q not found", req.GetJobId())
	}
	return &mediapb.JobStatusResponse{
		JobId: j.ID, Status: j.Status, ProgressPercent: j.Progress, CompletedAt: j.CompletedAt,
	}, nil
}

var stages = []struct {
	percent int32
	name    string
}{
	{25, "Demuxing input stream"},
	{50, "Encoding video frames"},
	{75, "Remuxing audio and headers"},
	{100, "Process completed successfully"},
}

func (s *server) setProgress(id string, percent int32) {
	s.mu.Lock()
	defer s.mu.Unlock()
	j := s.jobs[id]
	j.Progress = percent
	j.Status = statusProcessing
	if percent == 100 {
		j.Status = statusCompleted
		j.CompletedAt = time.Now().Unix()
	}
}

func (s *server) TrackProgress(req *mediapb.GetJobStatusRequest, stream mediapb.MediaService_TrackProgressServer) error {
	id := req.GetJobId()
	s.mu.RLock()
	j, ok := s.jobs[id]
	done := ok && j.Status == statusCompleted
	s.mu.RUnlock()
	if !ok {
		return status.Errorf(codes.NotFound, "job %q not found", id)
	}
	log.Printf("[STREAM] Client connected to track progress for JobID=%s", id)
	if done { // завдання вже виконано — віддаємо лише фінальне оновлення
		return stream.Send(&mediapb.ProgressUpdate{JobId: id, CurrentStage: stages[len(stages)-1].name, ProgressPercent: 100, IsCompleted: true})
	}

	for _, st := range stages {
		select {
		case <-stream.Context().Done(): // клієнт розірвав з'єднання / таймаут
			log.Printf("[STREAM] Client canceled tracking for JobID=%s, processing stopped", id)
			return status.Error(codes.Canceled, "Client canceled tracking")
		case <-time.After(700 * time.Millisecond):
			s.setProgress(id, st.percent)
			upd := &mediapb.ProgressUpdate{
				JobId: id, CurrentStage: st.name, ProgressPercent: st.percent, IsCompleted: st.percent == 100,
			}
			if err := stream.Send(upd); err != nil {
				return err
			}
			log.Printf("[STREAM] JobID=%s -> Sent stage %q (%d%%)", id, st.name, st.percent)
		}
	}
	log.Printf("[STREAM] Progress tracking finished for JobID=%s", id)
	return nil
}

func main() {
	addr := os.Getenv("ADDR")
	if addr == "" {
		addr = ":50051"
	}
	lis, err := net.Listen("tcp", addr)
	if err != nil {
		log.Fatalf("listen: %v", err)
	}
	srv := grpc.NewServer(
		grpc.UnaryInterceptor(serverInterceptor),
		grpc.StreamInterceptor(streamInterceptor),
	)
	mediapb.RegisterMediaServiceServer(srv, newServer())

	go func() {
		stop := make(chan os.Signal, 1)
		signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
		<-stop
		log.Println("[SERVER] Shutting down gracefully...")
		srv.GracefulStop()
	}()

	log.Printf("[SERVER] Starting Media Processing gRPC service on %s...", addr)
	if err := srv.Serve(lis); err != nil {
		log.Fatalf("serve: %v", err)
	}
}
