package main

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"os"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"

	mediapb "media-service/proto"
)

func main() {
	addr := "localhost:50051"
	if v := os.Getenv("ADDR"); v != "" {
		addr = v
	}
	conn, err := grpc.NewClient(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("connect: %v", err)
	}
	defer conn.Close()
	client := mediapb.NewMediaServiceClient(conn)

	fmt.Println("=== Media Processing Service CLI Client ===")
	req := &mediapb.ProcessMediaRequest{
		ClientId: "client-service-01", Filename: "input_video.mov",
		TargetFormat: mediapb.MediaFormat_MEDIA_FORMAT_MP4, QualityLevel: 80,
	}

	// Крок 1: негативний сценарій — без метаданих автентифікації
	fmt.Println("\n[Step 1] Attempting RPC call WITHOUT authentication metadata...")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	_, err = client.SubmitJob(ctx, req)
	cancel()
	if st, ok := status.FromError(err); ok && st.Code() == codes.Unauthenticated {
		fmt.Printf("[ERROR] Server responded with gRPC error: %v\n", err)
		fmt.Println("[INFO] Authentication enforcement verified successfully.")
	} else {
		log.Fatalf("expected Unauthenticated, got: %v", err)
	}

	// Некоректний ключ
	badCtx := metadata.NewOutgoingContext(context.Background(), metadata.Pairs("x-api-key", "wrong-key"))
	if _, err = client.SubmitJob(badCtx, req); status.Code(err) == codes.Unauthenticated {
		fmt.Println("[INFO] Request with an invalid key was rejected as well (Unauthenticated).")
	}

	// Крок 2: SubmitJob з коректним ключем
	fmt.Println("\n[Step 2] Sending SubmitJob request with valid metadata (x-api-key: secret-media-token)...")
	ctx, cancel = context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	ctx = metadata.NewOutgoingContext(ctx, metadata.Pairs("x-api-key", "secret-media-token"))
	job, err := client.SubmitJob(ctx, req)
	if err != nil {
		log.Fatalf("[ERROR] SubmitJob: %v", err)
	}
	fmt.Println("[SUCCESS] Job created successfully:")
	fmt.Printf("  - Job ID:        %s\n", job.GetJobId())
	fmt.Printf("  - Initial State: %s\n", job.GetStatus())
	fmt.Printf("  - Submitted At:  %s\n", time.Unix(job.GetCreatedAt(), 0).Format("2006-01-02 15:04:05"))

	// Крок 3: Server Streaming
	fmt.Println("\n[Step 3] Subscribing to Server Streaming: TrackProgress...")
	stream, err := client.TrackProgress(ctx, &mediapb.GetJobStatusRequest{JobId: job.GetJobId()})
	if err != nil {
		log.Fatalf("[ERROR] TrackProgress: %v", err)
	}
	for {
		upd, err := stream.Recv()
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			log.Fatalf("[ERROR] stream: %v", err)
		}
		fmt.Printf("  [%d%%] %s\n", upd.GetProgressPercent(), upd.GetCurrentStage())
	}

	// Крок 4: підсумковий статус
	fmt.Println("\n[Step 4] Checking final job status via GetJobStatus RPC...")
	st, err := client.GetJobStatus(ctx, &mediapb.GetJobStatusRequest{JobId: job.GetJobId()})
	if err != nil {
		log.Fatalf("[ERROR] GetJobStatus: %v", err)
	}
	fmt.Printf("  - Current Status: %s\n", st.GetStatus())
	fmt.Printf("  - Progress:       %d%%\n", st.GetProgressPercent())
	fmt.Printf("  - Completed At:   %s\n", time.Unix(st.GetCompletedAt(), 0).Format("2006-01-02 15:04:05"))

	// Додатково: NotFound
	fmt.Println("\n[Extra] GetJobStatus for a non-existent job...")
	if _, err = client.GetJobStatus(ctx, &mediapb.GetJobStatusRequest{JobId: "no-such-job"}); status.Code(err) == codes.NotFound {
		fmt.Printf("  [OK] %v\n", err)
	}
	fmt.Println("\n=== Processing pipeline finished successfully ===")
}
