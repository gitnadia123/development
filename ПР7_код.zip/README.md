# Media Processing Service (Практична робота №7, gRPC)

```bash
go install google.golang.org/protobuf/cmd/protoc-gen-go@latest
go install google.golang.org/grpc/cmd/protoc-gen-go-grpc@latest
make proto            # генерує proto/media.pb.go та proto/media_grpc.pb.go (потрібен protoc)
go mod tidy
go run ./cmd/server   # термінал 1  (:50051)
go run ./cmd/client   # термінал 2
```
grpcurl: `grpcurl -plaintext -H 'x-api-key: secret-media-token' -d '{"job_id":"..."}' localhost:50051 media.MediaService/GetJobStatus`
(reflection не вмикався — для grpcurl використовуйте `-proto proto/media.proto`).
