package main

import (
	"log"
	"net"
	"net/http"
	"time"

	"github.com/gorilla/websocket"
)

// Параметри Heartbeat (змінюються змінними середовища, див. main.go).
var (
	pingPeriod = 30 * time.Second
	pongWait   = 60 * time.Second
)

const (
	writeWait      = 10 * time.Second
	maxMessageSize = 4096
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin:     func(r *http.Request) bool { return true },
}

// Client — посередник між WebSocket-з'єднанням і Hub.
type Client struct {
	hub  *Hub
	conn *websocket.Conn
	send chan []byte
	room string
	addr string
}

// readPump — єдиний читач сокета.
func (c *Client) readPump() {
	defer func() {
		c.hub.unregister <- c
		c.conn.Close()
	}()
	c.conn.SetReadLimit(maxMessageSize)
	c.conn.SetReadDeadline(time.Now().Add(pongWait))
	c.conn.SetPongHandler(func(string) error {
		c.conn.SetReadDeadline(time.Now().Add(pongWait)) // продовжуємо дедлайн
		log.Printf("[HEARTBEAT] Pong отримано від клієнта %s", c.addr)
		return nil
	})
	for {
		_, data, err := c.conn.ReadMessage()
		if err != nil {
			if ne, ok := err.(net.Error); ok && ne.Timeout() {
				log.Printf("[HEARTBEAT] Pong від %s не отримано протягом %v — «завислий» сокет закрито примусово", c.addr, pongWait)
			} else if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseNormalClosure) {
				log.Printf("[WS] Помилка читання від %s: %v", c.addr, err)
			}
			return
		}
		c.hub.broadcast <- Message{Room: c.room, Sender: c.addr, Text: string(data)}
	}
}

// writePump — єдиний записувач у сокет (серіалізує запис) + відправка Ping.
func (c *Client) writePump() {
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		c.conn.Close()
	}()
	for {
		select {
		case msg, ok := <-c.send:
			c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if !ok { // Hub закрив канал
				c.conn.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
				return
			}
			if err := c.conn.WriteMessage(websocket.TextMessage, msg); err != nil {
				return
			}
		case <-ticker.C:
			c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
			log.Printf("[HEARTBEAT] Ping надіслано клієнту %s", c.addr)
		}
	}
}

// serveWS — GET /api/v1/ws?room=...
func serveWS(hub *Hub, w http.ResponseWriter, r *http.Request) {
	room := r.URL.Query().Get("room")
	if room == "" {
		room = "general"
	}
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("[WS] Upgrade failed: %v", err)
		return
	}
	c := &Client{hub: hub, conn: conn, send: make(chan []byte, 256), room: room, addr: r.RemoteAddr}
	hub.register <- c
	go c.writePump()
	c.readPump()
}
