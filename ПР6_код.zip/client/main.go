// Тестовий WebSocket-клієнт (аналог wscat) для середовища без Node/wscat.
// Режими:  -room R -send "текст" -wait 3s   — підключитись, (надіслати), слухати
//
//	-zombie                          — підключитись і НЕ читати (не відповідати Pong)
package main

import (
	"flag"
	"fmt"
	"net/url"
	"os"
	"time"

	"github.com/gorilla/websocket"
)

func main() {
	room := flag.String("room", "", "кімната")
	send := flag.String("send", "", "повідомлення")
	wait := flag.Duration("wait", 3*time.Second, "скільки слухати")
	zombie := flag.Bool("zombie", false, "не читати з сокета")
	host := flag.String("host", "localhost:8080", "host:port")
	flag.Parse()

	u := url.URL{Scheme: "ws", Host: *host, Path: "/api/v1/ws"}
	if *room != "" {
		u.RawQuery = "room=" + url.QueryEscape(*room)
	}
	c, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
	if err != nil {
		fmt.Println("dial error:", err)
		os.Exit(1)
	}
	defer c.Close()
	fmt.Printf("Connected (%s)\n", u.String())
	if *zombie {
		time.Sleep(*wait) // сокет відкритий, але ReadMessage не викликається → Pong не надсилається
		fmt.Println("zombie: завершено очікування")
		return
	}
	if *send != "" {
		time.Sleep(300 * time.Millisecond)
		c.WriteMessage(websocket.TextMessage, []byte(*send))
		fmt.Printf("> %s\n", *send)
	}
	c.SetReadDeadline(time.Now().Add(*wait))
	for {
		_, m, err := c.ReadMessage()
		if err != nil {
			fmt.Println("(кінець сеансу:", err, ")")
			c.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
			return
		}
		fmt.Printf("< %s\n", m)
	}
}
