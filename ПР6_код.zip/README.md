# Real-Time Operations Gateway (Практична робота №6, Go: SSE + WebSockets)

- `GET /api/v1/metrics/stream` — SSE-телеметрія (щосекунди: час, горутини, пам'ять)
- `GET /api/v1/ws?room=<name>` — WebSocket, патерн Hub, кімнати (за замовчуванням `general`), Ping/Pong
- `/` — вебклієнт (`web/index.html`, вбудований через go:embed)

## Запуск
```bash
go mod tidy
go run .                         # :8080
curl -N http://localhost:8080/api/v1/metrics/stream
go run ./client -room alerts -send "Привіт"   # тестовий WS-клієнт (замість wscat)
# або: wscat -c "ws://localhost:8080/api/v1/ws?room=alerts"
```
Heartbeat для демонстрації: `WS_PING_MS=2000 WS_PONG_WAIT_MS=5000 go run -race .`
(за замовчуванням Ping 30 с, Pong-таймаут 60 с). Скриншоти — у звіті.
