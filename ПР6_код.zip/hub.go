package main

import (
	"encoding/json"
	"log"
	"time"
)

// Message — структура повідомлення з інформацією про кімнату та відправника.
type Message struct {
	Room   string `json:"room"`
	Sender string `json:"sender"`
	Text   string `json:"text"`
	Time   string `json:"time"`
}

// Hub координує реєстрацію клієнтів і розсилку повідомлень у межах кімнат.
type Hub struct {
	clients    map[*Client]bool
	broadcast  chan Message
	register   chan *Client
	unregister chan *Client
}

func NewHub() *Hub {
	return &Hub{
		clients:    make(map[*Client]bool),
		broadcast:  make(chan Message, 256),
		register:   make(chan *Client),
		unregister: make(chan *Client),
	}
}

// Run — диспетчер: єдина горутина, що володіє мапою clients (без м'ютексів).
func (h *Hub) Run() {
	for {
		select {
		case c := <-h.register:
			h.clients[c] = true
			log.Printf("[WS] Новий клієнт підключився до кімнати [%s]: %s (усього: %d)", c.room, c.addr, len(h.clients))

		case c := <-h.unregister:
			if h.clients[c] {
				delete(h.clients, c)
				close(c.send)
				log.Printf("[WS] Клієнт %s залишив кімнату [%s]. Ресурси звільнено (усього: %d)", c.addr, c.room, len(h.clients))
			}

		case m := <-h.broadcast:
			m.Time = time.Now().Format(time.RFC3339)
			payload, _ := json.Marshal(m)
			log.Printf("[HUB BROADCAST] [Кімната: %s] Отримано повідомлення від %s: %q", m.Room, m.Sender, m.Text)
			n := 0
			for c := range h.clients {
				if c.room != m.Room { // розсилка лише в кімнату відправника
					continue
				}
				select {
				case c.send <- payload:
					n++
				default: // повільний клієнт: буфер переповнено — відключаємо
					delete(h.clients, c)
					close(c.send)
					log.Printf("[HUB] Буфер клієнта %s переповнено, з'єднання закрито", c.addr)
				}
			}
			log.Printf("[HUB BROADCAST] Сповіщено клієнтів у кімнаті [%s]: %d", m.Room, n)
		}
	}
}
