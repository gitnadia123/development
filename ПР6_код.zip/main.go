package main

import (
	"context"
	"embed"
	"io/fs"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"
)

//go:embed web
var webFS embed.FS

func envDuration(key string, def time.Duration) time.Duration {
	if v := os.Getenv(key); v != "" {
		if ms, err := strconv.Atoi(v); err == nil {
			return time.Duration(ms) * time.Millisecond
		}
	}
	return def
}

func main() {
	pingPeriod = envDuration("WS_PING_MS", pingPeriod)
	pongWait = envDuration("WS_PONG_WAIT_MS", pongWait)
	addr := os.Getenv("ADDR")
	if addr == "" {
		addr = ":8080"
	}
	log.SetFlags(log.Ltime)
	log.Println("=== Сервіс реального часу (SSE & WebSockets Gateway) ===")

	hub := NewHub()
	go hub.Run()
	log.Println("[СЕРВЕР] Диспетчер WebSocket Hub успішно запущено")

	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/v1/metrics/stream", metricsStream)
	mux.HandleFunc("GET /api/v1/ws", func(w http.ResponseWriter, r *http.Request) { serveWS(hub, w, r) })
	sub, _ := fs.Sub(webFS, "web")
	mux.Handle("/", http.FileServer(http.FS(sub)))

	srv := &http.Server{Addr: addr, Handler: mux}
	go func() {
		log.Printf("[СЕРВЕР] HTTP-слухач відкрито на порту %s", addr)
		if err := srv.ListenAndServe(); err != http.ErrServerClosed {
			log.Fatal(err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop
	log.Println("[СЕРВЕР] Отримано сигнал завершення...")
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	srv.Shutdown(ctx)
	log.Println("[СЕРВЕР] Зупинено")
}
