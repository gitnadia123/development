package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"runtime"
	"time"
)

type Metrics struct {
	Time       string  `json:"time"`
	Goroutines int     `json:"goroutines"`
	AllocKB    uint64  `json:"alloc_kb"`
	AllocMB    float64 `json:"alloc_mb"`
}

// metricsStream — GET /api/v1/metrics/stream (Server-Sent Events).
func metricsStream(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "Streaming unsupported", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")

	log.Printf("[SSE] Нове підключення клієнта телеметрії: %s", r.RemoteAddr)
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop() // зупинка таймера при виході

	send := func() bool {
		var ms runtime.MemStats
		runtime.ReadMemStats(&ms)
		m := Metrics{
			Time:       time.Now().Format(time.RFC3339),
			Goroutines: runtime.NumGoroutine(),
			AllocKB:    ms.Alloc / 1024,
			AllocMB:    float64(ms.Alloc) / 1024 / 1024,
		}
		b, _ := json.Marshal(m)
		if _, err := fmt.Fprintf(w, "data: %s\n\n", b); err != nil {
			return false
		}
		flusher.Flush()
		return true
	}
	if !send() {
		return
	}
	for {
		select {
		case <-r.Context().Done(): // клієнт відключився
			log.Printf("[SSE] Клієнт %s розірвав з'єднання. Очищення ресурсів виконано.", r.RemoteAddr)
			return
		case <-ticker.C:
			if !send() {
				return
			}
		}
	}
}
