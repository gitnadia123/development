package main

import (
	"flag"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"
)

// ---------- Рівень 1: структури, інтерфейс, послідовний моніторинг ----------

// Result — результат опитування однієї адреси.
type Result struct {
	URL      string
	Status   int
	Duration time.Duration
	Err      error
}

// Checker абстрагує операцію перевірки ресурсу.
type Checker interface {
	Check(url string) Result
}

// HTTPChecker — реалізація Checker на базі http.Client із таймаутом.
type HTTPChecker struct {
	client *http.Client
}

func NewHTTPChecker(timeout time.Duration) *HTTPChecker {
	return &HTTPChecker{client: &http.Client{Timeout: timeout}}
}

// Check виконує GET-запит і точно вимірює його тривалість.
func (c *HTTPChecker) Check(url string) Result {
	start := time.Now()
	resp, err := c.client.Get(url)
	elapsed := time.Since(start)
	if err != nil {
		return Result{URL: url, Duration: elapsed, Err: err}
	}
	defer resp.Body.Close()
	return Result{URL: url, Status: resp.StatusCode, Duration: elapsed}
}

func printResult(r Result) {
	if r.Err != nil {
		fmt.Printf("-> %s: Помилка (%v)\n", r.URL, r.Err)
		return
	}
	fmt.Printf("-> %s: Status %d %s (час: %v)\n", r.URL, r.Status,
		http.StatusText(r.Status), r.Duration.Round(time.Millisecond))
}

// checkSequential — послідовний прогін усіх адрес.
func checkSequential(c Checker, urls []string) []Result {
	results := make([]Result, 0, len(urls))
	for _, u := range urls {
		results = append(results, c.Check(u))
	}
	return results
}

// ---------- Рівень 2: горутини, WaitGroup, Mutex ----------

// Stats — спільна статистика, захищена м'ютексом.
type Stats struct {
	mu      sync.Mutex
	Total   int
	Success int // статус 200
	Errors  int
}

func (s *Stats) Add(r Result) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Total++
	if r.Err != nil {
		s.Errors++
	} else if r.Status == http.StatusOK {
		s.Success++
	}
}

// checkMutex — паралельний прогін, статистика збирається під Mutex.
func checkMutex(c Checker, urls []string) *Stats {
	var wg sync.WaitGroup
	stats := &Stats{}
	for _, u := range urls {
		wg.Add(1)                // до запуску горутини
		go func(target string) { // адреса передається аргументом
			defer wg.Done()
			stats.Add(c.Check(target))
		}(u)
	}
	wg.Wait()
	return stats
}

// ---------- Рівень 3: канали ----------

// checkChannels — паралельний прогін, результати передаються через канал.
func checkChannels(c Checker, urls []string) []Result {
	resultsChan := make(chan Result, len(urls))
	var wg sync.WaitGroup
	for _, u := range urls {
		wg.Add(1)
		go func(target string) {
			defer wg.Done()
			resultsChan <- c.Check(target)
		}(u)
	}
	// горутина-координатор: чекає всіх і закриває канал
	go func() {
		wg.Wait()
		close(resultsChan)
	}()

	var out []Result
	for res := range resultsChan {
		out = append(out, res)
	}
	return out
}

func main() {
	urlsFlag := flag.String("urls",
		"https://go.dev,https://github.com,https://httpbin.org/status/404,https://invalid-fake-host-test.org",
		"список адрес через кому")
	timeout := flag.Duration("timeout", 5*time.Second, "таймаут одного запиту")
	flag.Parse()
	urls := strings.Split(*urlsFlag, ",")
	checker := NewHTTPChecker(*timeout)

	fmt.Println("=== HTTP URL Health Checker ===")

	// Рівень 1
	fmt.Println("\n[Рівень 1. Послідовна перевірка адрес...]")
	t0 := time.Now()
	seq := checkSequential(checker, urls)
	seqTime := time.Since(t0)
	for _, r := range seq {
		printResult(r)
	}
	fmt.Printf("Загальний час послідовного режиму: %v\n", seqTime.Round(time.Millisecond))

	// Рівень 2
	fmt.Println("\n[Рівень 2. Паралельна перевірка + sync.Mutex...]")
	t1 := time.Now()
	stats := checkMutex(checker, urls)
	mutexTime := time.Since(t1)
	fmt.Printf("Mutex-статистика: усього=%d, успішних(200)=%d, помилок=%d, час=%v\n",
		stats.Total, stats.Success, stats.Errors, mutexTime.Round(time.Millisecond))

	// Рівень 3
	fmt.Println("\n[Рівень 3. Конкурентна перевірка адрес через канали...]")
	t2 := time.Now()
	results := checkChannels(checker, urls)
	chanTime := time.Since(t2)
	ok, failed := 0, 0
	for _, r := range results {
		printResult(r)
		if r.Err != nil {
			failed++
		} else {
			ok++
		}
	}

	fmt.Println("\n==========================================")
	fmt.Println("ПІДСУМКОВИЙ ЗВІТ МОНІТОРИНГУ:")
	fmt.Printf("- Усього перевірено адрес: %d\n", len(results))
	fmt.Printf("- Успішних з'єднань: %d\n", ok)
	fmt.Printf("- Мережевих помилок: %d\n", failed)
	fmt.Printf("- Загальний час роботи: %v (проти %v у послідовному режимі)\n",
		chanTime.Round(time.Millisecond), seqTime.Round(time.Millisecond))
	if chanTime > 0 {
		fmt.Printf("- Прискорення: у %.1f разів\n", float64(seqTime)/float64(chanTime))
	}
	fmt.Println("==========================================")
}
