// Локальний тестовий HTTP-сервер із імітацією затримок (для запуску без Інтернету).
package main

import (
	"fmt"
	"net/http"
	"strconv"
	"time"
)

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/delay/", func(w http.ResponseWriter, r *http.Request) {
		ms, _ := strconv.Atoi(r.URL.Path[len("/delay/"):])
		time.Sleep(time.Duration(ms) * time.Millisecond)
		fmt.Fprintln(w, "ok")
	})
	mux.HandleFunc("/status/404", func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(300 * time.Millisecond)
		http.NotFound(w, r)
	})
	http.ListenAndServe("127.0.0.1:18080", mux)
}
