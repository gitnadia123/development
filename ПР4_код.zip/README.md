# Device Registry API (Практична робота №4, Go + Chi)

REST API «Мережевий реєстр пристроїв»: CRUD, фільтрація `?status=&type=`, Middleware (Logger, Recoverer, CORS), єдиний формат помилок.

## Запуск
```bash
go mod tidy
go run ./cmd/server          # сервер на :8080
go test -race ./...          # тест потокобезпечності
```
## Приклади
```bash
curl -X POST localhost:8080/api/v1/devices -H 'Content-Type: application/json' \
  -d '{"name":"Main Thermal Sensor","ip_address":"192.168.1.50","type":"sensor","status":"online"}'
curl 'localhost:8080/api/v1/devices?status=online&type=sensor'
```
Скриншоти роботи — у звіті (docx).
