module deviceregistry

go 1.24

toolchain go1.24.7

require github.com/go-chi/chi/v5 v5.5.0
