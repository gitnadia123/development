package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"

	"github.com/go-chi/chi/v5"
	chimw "github.com/go-chi/chi/v5/middleware"

	"deviceregistry/internal/handler"
	"deviceregistry/internal/repository"
)

func main() {
	addr := flag.String("addr", ":8080", "адреса HTTP-сервера")
	flag.Parse()
	log.SetFlags(0)

	fmt.Println("=== Мережевий реєстр пристроїв (Device Registry API) ===")
	repo := repository.NewMemoryDeviceRepository()
	log.Println("[СЕРВЕР] Ініціалізація сховища даних (sync.RWMutex: active)")

	r := chi.NewRouter()
	r.Use(chimw.RequestID, chimw.RealIP) // RealIP змінює RemoteAddr: має бути перед Logger
	r.Use(handler.Logger, handler.Recoverer, handler.CORS)
	r.NotFound(handler.NotFoundHandler)
	r.MethodNotAllowed(handler.MethodNotAllowedHandler)
	log.Println("[СЕРВЕР] Конвеєр Middleware підключено: RequestID, RealIP, Logger, Recoverer, CORS")

	dh := handler.NewDeviceHandler(repo)
	r.Route("/api/v1/devices", dh.Routes)
	log.Println("[СЕРВЕР] Маршрути Chi змонтовано на префіксі /api/v1/devices")

	// Службовий маршрут для демонстрації Panic Recovery
	r.Get("/api/v1/debug/panic", func(w http.ResponseWriter, r *http.Request) {
		var m map[string]int
		m["boom"] = 1 // запис у nil-map → panic
	})

	log.Printf("[СЕРВЕР] HTTP-сервер запущено на порту %s...", *addr)
	log.Fatal(http.ListenAndServe(*addr, r))
}
