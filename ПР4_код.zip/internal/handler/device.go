// Пакет handler — HTTP-обробники запитів.
package handler

import (
	"encoding/json"
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"deviceregistry/internal/domain"
	"deviceregistry/internal/repository"
)

type DeviceHandler struct {
	repo repository.DeviceRepository
}

func NewDeviceHandler(repo repository.DeviceRepository) *DeviceHandler {
	return &DeviceHandler{repo: repo}
}

// Routes монтує суб-роутер ресурсу /devices.
func (h *DeviceHandler) Routes(r chi.Router) {
	r.Get("/", h.List)
	r.Post("/", h.Create)
	r.Route("/{id}", func(r chi.Router) {
		r.Get("/", h.Get)
		r.Put("/", h.Update)
		r.Delete("/", h.Delete)
	})
}

// validate перевіряє обов'язкові поля та допустимі значення.
func validate(d *domain.Device) string {
	var missing []string
	if strings.TrimSpace(d.Name) == "" {
		missing = append(missing, "name")
	}
	if strings.TrimSpace(d.IPAddress) == "" {
		missing = append(missing, "ip_address")
	}
	if strings.TrimSpace(d.Type) == "" {
		missing = append(missing, "type")
	}
	if len(missing) > 0 {
		return "Required fields are missing: " + strings.Join(missing, ", ")
	}
	if net.ParseIP(d.IPAddress) == nil {
		return "Field 'ip_address' must be a valid IP address"
	}
	if d.Status == "" {
		d.Status = "offline"
	}
	if d.Status != "online" && d.Status != "offline" {
		return "Field 'status' must be 'online' or 'offline'"
	}
	return ""
}

func decode(w http.ResponseWriter, r *http.Request, d *domain.Device) bool {
	if err := json.NewDecoder(r.Body).Decode(d); err != nil {
		WriteError(w, http.StatusBadRequest, "Invalid JSON", "Request body is not valid JSON: "+err.Error())
		return false
	}
	if msg := validate(d); msg != "" {
		WriteError(w, http.StatusBadRequest, "Validation Failed", msg)
		return false
	}
	return true
}

// List — GET /api/v1/devices[?status=...&type=...]
func (h *DeviceHandler) List(w http.ResponseWriter, r *http.Request) {
	f := domain.DeviceFilter{Status: r.URL.Query().Get("status"), Type: r.URL.Query().Get("type")}
	writeJSON(w, http.StatusOK, h.repo.GetAll(f))
}

// Create — POST /api/v1/devices
func (h *DeviceHandler) Create(w http.ResponseWriter, r *http.Request) {
	var d domain.Device
	if !decode(w, r, &d) {
		return
	}
	d.ID = h.repo.NextID()
	d.UpdatedAt = time.Now().UTC().Truncate(time.Second)
	if err := h.repo.Create(d); err != nil {
		WriteError(w, http.StatusInternalServerError, "Internal Server Error", err.Error())
		return
	}
	writeJSON(w, http.StatusCreated, d)
}

// Get — GET /api/v1/devices/{id}
func (h *DeviceHandler) Get(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	d, ok := h.repo.GetByID(id)
	if !ok {
		WriteError(w, http.StatusNotFound, "Resource Not Found", "Device with ID '"+id+"' does not exist in registry")
		return
	}
	writeJSON(w, http.StatusOK, d)
}

// Update — PUT /api/v1/devices/{id}
func (h *DeviceHandler) Update(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if _, ok := h.repo.GetByID(id); !ok {
		WriteError(w, http.StatusNotFound, "Resource Not Found", "Device with ID '"+id+"' does not exist in registry")
		return
	}
	var d domain.Device
	if !decode(w, r, &d) {
		return
	}
	d.ID = id
	d.UpdatedAt = time.Now().UTC().Truncate(time.Second)
	if !h.repo.Update(id, d) {
		WriteError(w, http.StatusNotFound, "Resource Not Found", "Device with ID '"+id+"' does not exist in registry")
		return
	}
	writeJSON(w, http.StatusOK, d)
}

// Delete — DELETE /api/v1/devices/{id}
func (h *DeviceHandler) Delete(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if !h.repo.Delete(id) {
		WriteError(w, http.StatusNotFound, "Resource Not Found", "Device with ID '"+id+"' does not exist in registry")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
