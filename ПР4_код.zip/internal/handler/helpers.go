package handler

import (
	"encoding/json"
	"net/http"
	"time"

	"deviceregistry/internal/domain"
)

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// WriteError — єдиний формат помилок для всього сервісу.
func WriteError(w http.ResponseWriter, status int, title, message string) {
	writeJSON(w, status, domain.ErrorResponse{
		Error: title, Message: message, Status: status, Timestamp: time.Now().UTC().Truncate(time.Second),
	})
}

func NotFoundHandler(w http.ResponseWriter, r *http.Request) {
	WriteError(w, http.StatusNotFound, "Resource Not Found", "Route "+r.Method+" "+r.URL.Path+" does not exist")
}

func MethodNotAllowedHandler(w http.ResponseWriter, r *http.Request) {
	WriteError(w, http.StatusMethodNotAllowed, "Method Not Allowed", "Method "+r.Method+" is not allowed for "+r.URL.Path)
}
