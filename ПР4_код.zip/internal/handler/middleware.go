package handler

import (
	"log"
	"net/http"
	"runtime/debug"
	"time"

	chimw "github.com/go-chi/chi/v5/middleware"
)

// Logger — власний middleware журналювання: адреса, метод, шлях, статус, тривалість.
func Logger(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		ww := chimw.NewWrapResponseWriter(w, r.ProtoMajor)
		next.ServeHTTP(ww, r)
		status := ww.Status()
		if status == 0 {
			status = http.StatusOK
		}
		log.Printf("[HTTP] %s - %s %s -> %d %s (%v)", r.RemoteAddr, r.Method, r.URL.RequestURI(),
			status, http.StatusText(status), time.Since(start).Round(time.Microsecond))
	})
}

// Recoverer — Panic Recovery: перехоплює паніку, логує стек і повертає 500 у єдиному форматі.
func Recoverer(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if rec := recover(); rec != nil {
				log.Printf("[PANIC] %v\n%s", rec, debug.Stack())
				WriteError(w, http.StatusInternalServerError, "Internal Server Error",
					"Unexpected internal error occurred while processing the request")
			}
		}()
		next.ServeHTTP(w, r)
	})
}

// CORS — міждоменний доступ для браузерних застосунків.
func CORS(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("Access-Control-Allow-Origin", "*")
		h.Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		h.Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		if r.Method == http.MethodOptions { // preflight
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}
