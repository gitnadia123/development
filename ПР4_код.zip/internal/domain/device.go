// Пакет domain — доменні моделі реєстру пристроїв.
package domain

import "time"

// Device — мережевий вузол (датчик, шлюз, контролер).
type Device struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	IPAddress string    `json:"ip_address"`
	Type      string    `json:"type"`   // sensor, gateway, controller
	Status    string    `json:"status"` // online, offline
	UpdatedAt time.Time `json:"updated_at"`
}

// DeviceFilter — критерії фільтрації списку (порожнє поле = не фільтрувати).
type DeviceFilter struct {
	Status string
	Type   string
}

// ErrorResponse — єдиний формат відповіді про помилку (у дусі RFC 7807).
type ErrorResponse struct {
	Error     string    `json:"error"`
	Message   string    `json:"message"`
	Status    int       `json:"status"`
	Timestamp time.Time `json:"timestamp"`
}
