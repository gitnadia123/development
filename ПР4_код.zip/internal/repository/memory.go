// Пакет repository — шар збереження стану.
package repository

import (
	"errors"
	"fmt"
	"sort"
	"sync"

	"deviceregistry/internal/domain"
)

// DeviceRepository — контракт сховища пристроїв.
type DeviceRepository interface {
	GetAll(f domain.DeviceFilter) []domain.Device
	GetByID(id string) (domain.Device, bool)
	Create(device domain.Device) error
	Update(id string, device domain.Device) bool
	Delete(id string) bool
	NextID() string
}

// MemoryDeviceRepository — потокобезпечне in-memory сховище на map + sync.RWMutex.
type MemoryDeviceRepository struct {
	mu      sync.RWMutex
	storage map[string]domain.Device
	seq     int
}

func NewMemoryDeviceRepository() *MemoryDeviceRepository {
	return &MemoryDeviceRepository{storage: make(map[string]domain.Device)}
}

// NextID генерує унікальний ідентифікатор виду dev-001.
func (r *MemoryDeviceRepository) NextID() string {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.seq++
	return fmt.Sprintf("dev-%03d", r.seq)
}

// GetAll повертає пристрої, що відповідають УСІМ заданим критеріям (читання — RLock).
func (r *MemoryDeviceRepository) GetAll(f domain.DeviceFilter) []domain.Device {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]domain.Device, 0, len(r.storage))
	for _, d := range r.storage {
		if f.Status != "" && d.Status != f.Status {
			continue
		}
		if f.Type != "" && d.Type != f.Type {
			continue
		}
		out = append(out, d)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (r *MemoryDeviceRepository) GetByID(id string) (domain.Device, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	d, ok := r.storage[id]
	return d, ok
}

func (r *MemoryDeviceRepository) Create(device domain.Device) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, exists := r.storage[device.ID]; exists {
		return errors.New("device already exists")
	}
	r.storage[device.ID] = device
	return nil
}

// Update замінює пристрій за id (ексклюзивний запис — Lock).
func (r *MemoryDeviceRepository) Update(id string, device domain.Device) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, ok := r.storage[id]; !ok {
		return false
	}
	device.ID = id
	r.storage[id] = device
	return true
}

func (r *MemoryDeviceRepository) Delete(id string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, ok := r.storage[id]; !ok {
		return false
	}
	delete(r.storage, id)
	return true
}
