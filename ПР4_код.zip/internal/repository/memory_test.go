package repository

import (
	"fmt"
	"sync"
	"testing"

	"deviceregistry/internal/domain"
)

// Тест потокобезпечності: запускати з go test -race.
func TestConcurrentAccess(t *testing.T) {
	r := NewMemoryDeviceRepository()
	var wg sync.WaitGroup
	for w := 0; w < 50; w++ {
		wg.Add(1)
		go func(w int) {
			defer wg.Done()
			for i := 0; i < 200; i++ {
				id := r.NextID()
				r.Create(domain.Device{ID: id, Name: fmt.Sprint("d", w), Type: "sensor", Status: "online"})
				r.GetByID(id)
				r.GetAll(domain.DeviceFilter{Status: "online"})
				r.Update(id, domain.Device{Name: "x", Type: "sensor", Status: "offline"})
				if i%2 == 0 {
					r.Delete(id)
				}
			}
		}(w)
	}
	wg.Wait()
	if got := len(r.GetAll(domain.DeviceFilter{})); got != 50*100 {
		t.Fatalf("очікувалось %d пристроїв, отримано %d", 50*100, got)
	}
}

func TestFilter(t *testing.T) {
	r := NewMemoryDeviceRepository()
	r.Create(domain.Device{ID: "a", Type: "sensor", Status: "online"})
	r.Create(domain.Device{ID: "b", Type: "sensor", Status: "offline"})
	r.Create(domain.Device{ID: "c", Type: "gateway", Status: "online"})
	if n := len(r.GetAll(domain.DeviceFilter{Status: "online"})); n != 2 {
		t.Fatalf("status=online: %d", n)
	}
	if n := len(r.GetAll(domain.DeviceFilter{Status: "online", Type: "sensor"})); n != 1 {
		t.Fatalf("status+type: %d", n)
	}
	if n := len(r.GetAll(domain.DeviceFilter{})); n != 3 {
		t.Fatalf("без фільтра: %d", n)
	}
}
