package main

import (
	"bufio"
	"flag"
	"fmt"
	"log"
	"net"
	"os"
	"os/signal"
	"strings"
	"sync"
	"syscall"
	"time"
)

// Server зберігає активні TCP-з'єднання; доступ до map захищено RWMutex.
type Server struct {
	mu       sync.RWMutex
	clients  map[net.Conn]struct{}
	wg       sync.WaitGroup
	tcp      net.Listener
	udp      net.PacketConn
	shutdown chan struct{}
}

func NewServer() *Server {
	return &Server{clients: make(map[net.Conn]struct{}), shutdown: make(chan struct{})}
}

func send(conn net.Conn, format string, a ...any) {
	fmt.Fprintf(conn, format+"\n", a...)
}

// ---------- Менеджер клієнтів та широкомовна розсилка (рівень 2) ----------

func (s *Server) add(c net.Conn) {
	s.mu.Lock()
	s.clients[c] = struct{}{}
	s.mu.Unlock()
}

func (s *Server) remove(c net.Conn) {
	s.mu.Lock()
	delete(s.clients, c)
	s.mu.Unlock()
}

// broadcast надсилає повідомлення всім клієнтам, крім except (може бути nil).
// Повертає кількість отримувачів.
func (s *Server) broadcast(except net.Conn, format string, a ...any) int {
	msg := fmt.Sprintf(format, a...) + "\n"
	s.mu.RLock()
	defer s.mu.RUnlock()
	n := 0
	for c := range s.clients {
		if c == except {
			continue
		}
		c.SetWriteDeadline(time.Now().Add(2 * time.Second))
		if _, err := c.Write([]byte(msg)); err == nil {
			n++
		}
	}
	return n
}

// ---------- Обробник TCP-з'єднання (рівень 1) ----------

func (s *Server) handleConnection(conn net.Conn) {
	defer s.wg.Done()
	addr := conn.RemoteAddr().String()
	s.add(conn)
	defer func() { // гарантоване видалення клієнта
		s.remove(conn)
		conn.Close()
		s.broadcast(nil, "[СИСТЕМА] Клієнт %s вийшов із мережі", addr)
		log.Printf("[ВІДКЛЮЧЕННЯ] Клієнт вийшов: %s", addr)
	}()

	log.Printf("[ПІДКЛЮЧЕННЯ] Новий клієнт підключився: %s", addr)
	send(conn, "[СЕРВЕР] Ласкаво просимо до мережевого сервісу диспетчеризації!")
	s.broadcast(conn, "[СИСТЕМА] Підключився новий клієнт: %s", addr)

	reader := bufio.NewReader(conn)
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			return // розрив з'єднання, закриття сервером або помилка мережі
		}
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		cmd, arg, _ := strings.Cut(line, " ")
		switch strings.ToUpper(cmd) {
		case "ECHO":
			send(conn, "[ECHO]: %s", arg)
		case "TIME":
			send(conn, "[TIME]: %s", time.Now().Format(time.RFC3339))
		case "BROADCAST", "MSG":
			n := s.broadcast(conn, "[СПОВІЩЕННЯ від %s]: %s", addr, arg)
			log.Printf("[РОЗСИЛКА] Від %s -> %q (отримувачів: %d)", addr, arg, n)
		case "CLOSE", "QUIT":
			send(conn, "[СЕРВЕР] До побачення!")
			return
		default:
			send(conn, "[ПОМИЛКА] Невідома команда %q. Доступні: ECHO <текст>, TIME, BROADCAST <текст> | MSG <текст>, CLOSE | QUIT", cmd)
		}
	}
}

// ---------- TCP-слухач ----------

func (s *Server) serveTCP(addr string) error {
	l, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	s.tcp = l
	log.Printf("[СЕРВЕР] TCP-слухач успішно відкрито на порту %s", strings.TrimPrefix(addr, ":"))
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		for {
			conn, err := l.Accept()
			if err != nil {
				select {
				case <-s.shutdown:
					return
				default:
					log.Printf("[ПОМИЛКА] Accept: %v", err)
					return
				}
			}
			s.wg.Add(1)
			go s.handleConnection(conn)
		}
	}()
	return nil
}

// ---------- UDP-телеметрія (рівень 3) ----------

func (s *Server) serveUDP(addr string) error {
	pc, err := net.ListenPacket("udp", addr)
	if err != nil {
		return err
	}
	s.udp = pc
	log.Printf("[СЕРВЕР] UDP-слухач телеметрії відкрито на порту %s", strings.TrimPrefix(addr, ":"))
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		buf := make([]byte, 1024)
		for {
			n, from, err := pc.ReadFrom(buf)
			if err != nil {
				select {
				case <-s.shutdown:
					return
				default:
					log.Printf("[ПОМИЛКА] UDP: %v", err)
					return
				}
			}
			data := strings.TrimSpace(string(buf[:n]))
			log.Printf("[UDP ТЕЛЕМЕТРІЯ] Отримано %d байт від %s -> %q", n, from, data)
			s.broadcast(nil, "[TELEMETRY from %s]: %s", from, data)
		}
	}()
	return nil
}

// ---------- Graceful Shutdown ----------

func (s *Server) Shutdown() {
	close(s.shutdown)
	s.mu.RLock()
	count := len(s.clients)
	s.mu.RUnlock()
	s.broadcast(nil, "[СИСТЕМА]: SERVER_SHUTTING_DOWN")
	s.tcp.Close()
	s.udp.Close()
	s.mu.RLock()
	for c := range s.clients {
		c.Close() // розблоковує ReadString у обробниках
	}
	s.mu.RUnlock()
	s.wg.Wait()
	log.Printf("[СЕРВЕР] Сповіщено активних клієнтів: %d. З'єднання безпечно закриті.", count)
}

func main() {
	tcpPort := flag.String("tcp", ":9000", "TCP-адреса")
	udpPort := flag.String("udp", ":9001", "UDP-адреса")
	flag.Parse()
	log.SetFlags(0)
	fmt.Printf("=== Мережевий сервіс диспетчеризації (TCP: %s, UDP: %s) ===\n",
		strings.TrimPrefix(*tcpPort, ":"), strings.TrimPrefix(*udpPort, ":"))

	srv := NewServer()
	if err := srv.serveTCP(*tcpPort); err != nil {
		log.Fatal(err)
	}
	if err := srv.serveUDP(*udpPort); err != nil {
		log.Fatal(err)
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop
	log.Println("[СЕРВЕР] Отримано сигнал завершення роботи. Запуск Graceful Shutdown...")
	srv.Shutdown()
	log.Println("[СЕРВЕР] Роботу сервера успішно завершено.")
}
