// Власний тестовий клієнт: читає команди зі stdin, виводить усе, що надсилає сервер.
// З прапорцем -udp надсилає одну датаграму (рядок із -msg).
package main

import (
	"bufio"
	"flag"
	"fmt"
	"net"
	"os"
)

func main() {
	addr := flag.String("addr", "localhost:9000", "адреса сервера")
	udp := flag.Bool("udp", false, "надіслати UDP-датаграму")
	msg := flag.String("msg", "", "вміст датаграми")
	flag.Parse()

	if *udp {
		c, err := net.Dial("udp", *addr)
		if err != nil {
			fmt.Println(err)
			os.Exit(1)
		}
		defer c.Close()
		c.Write([]byte(*msg))
		return
	}

	conn, err := net.Dial("tcp", *addr)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	defer conn.Close()
	done := make(chan struct{})
	go func() {
		sc := bufio.NewScanner(conn)
		for sc.Scan() {
			fmt.Println(sc.Text())
		}
		fmt.Println("Connection to", *addr, "closed by remote host.")
		close(done)
	}()
	in := bufio.NewScanner(os.Stdin)
	for in.Scan() {
		fmt.Println("> " + in.Text())
		fmt.Fprintln(conn, in.Text())
	}
	<-done
}
