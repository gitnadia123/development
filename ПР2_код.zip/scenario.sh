#!/bin/bash
# Сценарій демонстрації: 3 TCP-клієнти, UDP-датаграма, масова розсилка, Ctrl+C (SIGINT)
cd "$(dirname "$0")"; O=out; rm -f $O/*.log
/tmp/srv2 -tcp :9000 -udp :9001 > $O/server.log 2>&1 &
SP=$!; sleep 0.7
# Клієнт 1
( sleep 0.3; echo "ECHO Тестова перевірка"; sleep 0.3; echo "TIME"; sleep 0.3; echo "FOO"
  sleep 1.2; echo "BROADCAST Усім привіт у диспетчерській!"; sleep 3.4
  for i in $(seq 1 100); do echo "MSG c1-$i"; done; sleep 4 ) | /tmp/cli2 -addr localhost:9000 > $O/client1.log 2>&1 &
sleep 0.5
# Клієнт 2
( sleep 5.0; for i in $(seq 1 100); do echo "MSG c2-$i"; done; sleep 5 ) | /tmp/cli2 -addr localhost:9000 > $O/client2.log 2>&1 &
sleep 0.5
# Клієнт 3: перевіряє QUIT
( sleep 1.5; echo "QUIT"; sleep 1 ) | /tmp/cli2 -addr localhost:9000 > $O/client3.log 2>&1 &
sleep 2.0
# UDP-датаграма телеметрії
/tmp/cli2 -udp -addr localhost:9001 -msg "temp=24.5;press=750"
sleep 5.5
kill -INT $SP; wait $SP; sleep 0.5
